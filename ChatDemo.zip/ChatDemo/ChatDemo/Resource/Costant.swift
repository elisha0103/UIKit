//
//  Costant.swift
//  ChatDemo
//
//  Created by 진태영 on 11/3/23.
//

import Foundation

import FirebaseFirestore

let DB_REF = Firestore.firestore()
let REF_USERS = DB_REF.collection("users")
